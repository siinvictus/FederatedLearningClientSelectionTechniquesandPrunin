DATASETS = ['sent140', 'femnist', 'shakespeare', 'celeba', 'synthetic']
SEED_FILES = { 'sampling': 'sampling_seed.txt', 'split': 'split_seed.txt' }
